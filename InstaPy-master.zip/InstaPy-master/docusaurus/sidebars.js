module.exports = {
  docs: {
    Documentation: [
      'home',
      'settings',
      'actions',
      'third-party-features',
      'instance-settings',
      'relationship-tools',
      'automate-instapy',
      'additional-information',
    ],
  },
};
