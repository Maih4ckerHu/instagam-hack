#!/usr/bin/env python
# flake8: noqa
"""plugins to the instapy library"""

from .telegram_util import InstaPyTelegramBot
