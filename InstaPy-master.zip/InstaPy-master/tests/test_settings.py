from instapy import Settings


def test_settings():
    assert Settings.log_location == None
